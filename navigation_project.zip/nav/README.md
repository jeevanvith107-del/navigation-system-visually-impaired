# Navigation System for Visually Impaired
Real-time obstacle detection and shortest-path (A*) audio guidance — CSD2002 Introduction to Data Science mini project.

A simulated 5-stage pipeline: **Capture (deque buffer) → Detect (zones) → Distance & Risk (pinhole + hash map) → Route (weighted graph + A* min-heap) → Voice output (Streamlit)**.

## Files
| File | Purpose |
|---|---|
| `navigation_pipeline.py` | Core pipeline (deque, dict, graph, heapq A*) |
| `generate_dataset.py` | Generates the synthetic datasets (seed 42) |
| `data/navigation_scenes.csv` | 2,000 simulated scenes (class, true distance, noisy bbox, ground-truth risk/reroute) |
| `data/frame_sequences.csv` | 1,000 five-frame sequences for testing the temporal buffer |
| `navigation_demo.py` | Evaluation (MAE, RMSE, MAPE, accuracies) + figures |
| `app.py` | Interactive Streamlit simulator |
| `results/` | Metrics CSVs and generated plots |

## Setup
```bash
pip install -r requirements.txt
```

## Run
```bash
python generate_dataset.py              # (optional) regenerate the data
python navigation_demo.py               # full evaluation on 2,000 scenes
python navigation_demo.py --case staircase   # single test case (also: person, none)
streamlit run app.py                    # interactive simulator
```

## Results (simulation)
| Metric | Result |
|---|---|
| Distance MAE | 0.080 m |
| Distance RMSE | 0.114 m |
| Distance MAPE | 2.40 % |
| Risk-level accuracy | 99.60 % |
| Reroute-decision accuracy | 99.45 % |
| Ghost detections passed | 0.0 % |
| Persistent obstacle confirmed | 99.4 % |

> These come from a controlled simulation of the measurement model, not field trials with real camera footage.

## Author
Anvith Kumar — 20251ADS0139 — B.Tech AI & DS, Presidency University
