"""
navigation_demo.py
Runs the full 5-stage pipeline on the generated dataset, prints the evaluation
metrics (MAE, RMSE, MAPE, risk / reroute accuracy, temporal-buffer tests), saves
plots to results/, and can run a single named test case.

Usage:
  python navigation_demo.py                 # full evaluation + figures
  python navigation_demo.py --case staircase|person|none
  python navigation_demo.py --case staircase --speak     # needs: pip install pyttsx3
"""
import argparse
import math
import os
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from navigation_pipeline import (Detection, TemporalFrameBuffer, SpatialNavigationGraph,
                                 build_walkway_graph, evaluate_navigation_step,
                                 estimate_distance, FRAME_WIDTH_PX)

EDGE = ("Corridor_Start", "Exit_Lobby")
START, GOAL = EDGE


def run_scene(det):
    """Run one detection through the pipeline (1 warm-up frame + 1 decision frame)."""
    graph, buf = build_walkway_graph(), TemporalFrameBuffer(5, 2)
    args = (graph, START, GOAL, EDGE)
    evaluate_navigation_step([det], buf, *args)
    guidance, route, cost = evaluate_navigation_step([det], buf, *args)
    penalized = graph.adj[START][GOAL] != graph.base[EDGE]
    return guidance, route, cost, penalized


def speak(text):
    try:
        import pyttsx3
        eng = pyttsx3.init(); eng.say(text); eng.runAndWait()
    except Exception as e:
        print(f"[speech unavailable: {e}]")


def plot_case(det, guidance, route, cost, path):
    graph = build_walkway_graph()
    fig, (a1, a2) = plt.subplots(1, 2, figsize=(11, 4.5), gridspec_kw={"width_ratios": [1, 1.1]})
    a1.set_xlim(0, FRAME_WIDTH_PX); a1.set_ylim(480, 0)
    a1.axvspan(0, .35 * FRAME_WIDTH_PX, color="#cfe0f5", alpha=.5)
    a1.axvspan(.35 * FRAME_WIDTH_PX, .65 * FRAME_WIDTH_PX, color="#f5d5d5", alpha=.5)
    a1.axvspan(.65 * FRAME_WIDTH_PX, FRAME_WIDTH_PX, color="#cfe0f5", alpha=.5)
    x0, y0, x1, y1 = det.bbox
    a1.add_patch(plt.Rectangle((x0, y0), x1 - x0, y1 - y0, fill=False, ec="red", lw=2))
    a1.text(max(x0, 5), y0 - 6, f"{det.label} {det.confidence:.2f}", color="red")
    for name, x in (("LEFT", 100), ("CENTER", 320), ("RIGHT", 540)):
        a1.text(x, 470, name, ha="center", fontsize=8)
    a1.set_title("Stages 1-3: camera frame, zones, detection")
    for u, nb in graph.adj.items():
        for v in nb:
            if u < v:
                (ax, ay), (bx, by) = graph.coords[u], graph.coords[v]
                a2.plot([ax, bx], [ay, by], color="#9db0c8", lw=1.5)
                a2.text((ax + bx) / 2, (ay + by) / 2, f"{graph.base[(u, v)]:.1f}", fontsize=8)
    for n, (x, y) in graph.coords.items():
        a2.scatter(x, y, s=80, color="#12285a", zorder=3)
        a2.annotate(n, (x, y), textcoords="offset points", xytext=(5, 6), fontsize=7)
    xs = [graph.coords[n][0] for n in route]; ys = [graph.coords[n][1] for n in route]
    a2.plot(xs, ys, color="seagreen", lw=3.5, label=f"A* route (cost {cost:.2f})")
    a2.set_xlabel("x (m)"); a2.set_ylabel("y (m)"); a2.legend(loc="lower right")
    a2.set_title("Stage 4: weighted graph + A* (min-heap)")
    title = f"Obstacle: {guidance.obstacle} | Distance: {guidance.distance_m}m | Zone: {guidance.zone}\n" \
            f"{guidance.risk_level} | {guidance.direction_cue}" if guidance else "Path Clear | Continue Straight"
    fig.suptitle(title, color="darkred" if guidance else "green", fontsize=10)
    fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)


def single_case(name, speak_out):
    cases = {"staircase": ("Staircase", 655, 320), "person": ("Person", 125, 510), "none": (None, 0, 0)}
    label, w, cx = cases[name]
    det = Detection(label, 0.95, (int(cx - w / 2), 100, int(cx + w / 2), 440)) if label else None
    if det is None:
        print("Path Clear | Continue Straight (Corridor_Start -> Exit_Lobby, 8.0m)"); return
    g, route, cost, _ = run_scene(det)
    print(f"Obstacle: {g.obstacle} | Distance: {g.distance_m}m | Zone: {g.zone}")
    print(f"Output : {g.risk_level} | {g.direction_cue}")
    print(f"Route  : {' -> '.join(route)} (Cost: {cost:.2f})")
    print(f"Spoken : {g.voice_prompt}")
    os.makedirs("results", exist_ok=True)
    plot_case(det, g, route, cost, f"results/demo_{name}.png")
    print(f"Figure saved to results/demo_{name}.png")
    if speak_out:
        speak(g.voice_prompt)


def full_evaluation():
    os.makedirs("results", exist_ok=True)
    df = pd.read_csv("data/navigation_scenes.csv")
    est, risk_pred, reroute_pred = [], [], []
    for r in df.itertuples():
        det = Detection(r.label, r.confidence, (r.bbox_xmin, r.bbox_ymin, r.bbox_xmax, r.bbox_ymax))
        est.append(estimate_distance(det))
        g, _, _, pen = run_scene(det)
        risk_pred.append(g.risk_level if g else None)
        reroute_pred.append(int(pen))
    df["est_distance_m"] = est
    df["pred_risk"], df["pred_reroute"] = risk_pred, reroute_pred
    err = df.est_distance_m - df.true_distance_m
    mae, rmse = err.abs().mean(), math.sqrt((err ** 2).mean())
    mape = (err.abs() / df.true_distance_m).mean() * 100
    risk_acc = (df.pred_risk == df.true_risk).mean() * 100
    rr_acc = (df.pred_reroute == df.true_reroute).mean() * 100

    # temporal buffer test
    seq = pd.read_csv("data/frame_sequences.csv")
    ghost_pass, persist_ok, n_g, n_p = 0, 0, 0, 0
    for _, s in seq.groupby("sequence_id"):
        buf, confirmed_any = TemporalFrameBuffer(5, 2), False
        label = s.label.iloc[0]
        for d in s.detected:
            dets = [Detection(label, 0.9, (200, 100, 300, 400))] if d else []
            if buf.push_and_filter(dets):
                confirmed_any = True
        if s.is_persistent_obstacle.iloc[0]:
            n_p += 1; persist_ok += confirmed_any
        else:
            n_g += 1; ghost_pass += confirmed_any
    ghost_rate, persist_rate = ghost_pass / n_g * 100, persist_ok / n_p * 100

    metrics = pd.DataFrame({
        "Metric": ["Distance MAE (m)", "Distance RMSE (m)", "Distance MAPE (%)", "Risk-level accuracy (%)",
                   "Reroute-decision accuracy (%)", "Single-frame ghosts passed (%)", "Persistent obstacle confirmed (%)"],
        "Result": [round(mae, 3), round(rmse, 3), round(mape, 2), round(risk_acc, 2),
                   round(rr_acc, 2), round(ghost_rate, 1), round(persist_rate, 1)]})
    print(f"\n=== EVALUATION ON {len(df)} SIMULATED SCENES ===")
    print(metrics.to_string(index=False))
    metrics.to_csv("results/metrics.csv", index=False)
    df.to_csv("results/scene_predictions.csv", index=False)

    fig, (a, b) = plt.subplots(1, 2, figsize=(11, 4.2))
    a.scatter(df.true_distance_m, df.est_distance_m, s=4, alpha=.5, color="#12285a")
    a.plot([0.6, 6], [0.6, 6], color="red", lw=1)
    a.set_xlabel("True distance (m)"); a.set_ylabel("Pinhole estimate (m)")
    a.set_title(f"Distance estimation (MAE {mae:.3f} m)")
    b.hist(err, bins=40, color="#12285a")
    b.set_xlabel("Estimation error (m)"); b.set_ylabel("Scenes")
    b.set_title(f"Error distribution (RMSE {rmse:.3f} m)")
    fig.tight_layout(); fig.savefig("results/evaluation_plots.png", dpi=130); plt.close(fig)

    # standard demo figure
    det = Detection("Staircase", 0.95, (int(320 - 655 / 2), 100, int(320 + 655 / 2), 440))
    g, route, cost, _ = run_scene(det)
    plot_case(det, g, route, cost, "results/demo_staircase.png")
    print("\nSaved: results/metrics.csv, scene_predictions.csv, evaluation_plots.png, demo_staircase.png")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--case", choices=["staircase", "person", "none"])
    ap.add_argument("--speak", action="store_true")
    a = ap.parse_args()
    single_case(a.case, a.speak) if a.case else full_evaluation()
