"""Streamlit Navigation Simulator.  Run:  streamlit run app.py"""
import streamlit as st
from navigation_pipeline import (Detection, TemporalFrameBuffer, build_walkway_graph,
                                 evaluate_navigation_step)

st.set_page_config(page_title="Navigation System for Visually Impaired", layout="centered")
st.title("Navigation System for Visually Impaired")
st.caption("Real-Time Obstacle Detection & A* Audio Guidance")

obstacle_choice = st.selectbox("Select Simulated Camera Obstacle:",
                               ["Staircase", "Person", "Chair", "Bicycle", "Wet_Floor", "Car", "None"])
bbox_width = st.slider("Detected Bounding-Box Width (px):", 80, 700, 655)
center_x = st.slider("Horizontal Position in Frame (px):", 60, 580, 320)

if st.button("Analyze Surroundings"):
    graph, buf = build_walkway_graph(), TemporalFrameBuffer(5, 2)
    detections = []
    if obstacle_choice != "None":
        xmin, xmax = int(center_x - bbox_width / 2), int(center_x + bbox_width / 2)
        detections = [Detection(obstacle_choice, 0.95, (xmin, 100, xmax, 440))]
    args = (graph, "Corridor_Start", "Exit_Lobby", ("Corridor_Start", "Exit_Lobby"))
    evaluate_navigation_step(detections, buf, *args)             # frame 1: warm-up vote
    guidance, route, cost = evaluate_navigation_step(detections, buf, *args)

    if guidance is None:
        st.success(f"Path Clear | Continue Straight ({' -> '.join(route)}, {cost:.1f}m)")
    else:
        st.info(f"Obstacle: {guidance.obstacle} | Distance: {guidance.distance_m}m | Zone: {guidance.zone}")
        (st.error if guidance.risk_level == "HIGH RISK" else st.warning)(
            f"{guidance.risk_level} | {guidance.direction_cue}")
        st.write(f"Route: {' -> '.join(route)} (Cost: {cost:.2f})")
        st.caption("Spoken audio: " + guidance.voice_prompt)
