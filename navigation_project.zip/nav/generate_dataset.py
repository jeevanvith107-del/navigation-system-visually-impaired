"""
generate_dataset.py
Generates the synthetic datasets used by the demo (seed = 42):
  data/navigation_scenes.csv          2,000 simulated camera scenes
  data/frame_sequences.csv            1,000 five-frame sequences (temporal buffer test)
Each scene simulates what a YOLOv8n detector would output: a bounding box whose
pixel width follows the pinhole model with 3% Gaussian measurement noise.
"""
import os
import numpy as np
import pandas as pd
from navigation_pipeline import HAZARD_SPECS, DEFAULT_FOCAL_LENGTH_PX, FRAME_WIDTH_PX

SEED = 42
N_SCENES = 2000
N_SEQUENCES = 1000
NOISE = 0.03


def zone_of(xc):
    return "Left" if xc < 0.35 * FRAME_WIDTH_PX else ("Right" if xc > 0.65 * FRAME_WIDTH_PX else "Center")


def make_scenes(rng):
    labels = list(HAZARD_SPECS)
    rows = []
    for i in range(N_SCENES):
        label = rng.choice(labels)
        w_real, lam = HAZARD_SPECS[label]
        dist = rng.uniform(0.6, 6.0)
        true_w = w_real * DEFAULT_FOCAL_LENGTH_PX / dist
        meas_w = max(1, int(round(true_w * (1 + rng.normal(0, NOISE)))))
        cx = int(rng.integers(60, 581))
        rows.append({
            "scene_id": i + 1,
            "label": label,
            "confidence": round(float(rng.uniform(0.55, 0.99)), 2),
            "true_distance_m": round(dist, 3),
            "real_width_m": w_real,
            "risk_multiplier": lam,
            "center_x_px": cx,
            "bbox_xmin": int(cx - meas_w / 2),
            "bbox_ymin": 100,
            "bbox_xmax": int(cx + meas_w / 2),
            "bbox_ymax": 440,
            "measured_width_px": meas_w,
            "true_zone": zone_of(cx),
            "true_risk": "HIGH RISK" if (zone_of(cx) == "Center" and dist < 1.5) else "MODERATE RISK",
            "true_reroute": int(zone_of(cx) == "Center" and dist <= 3.0),
        })
    return pd.DataFrame(rows)


def make_sequences(rng, p_detect=0.80):
    """Half persistent obstacles (detected w.p. 0.8/frame), half single-frame ghosts."""
    labels = list(HAZARD_SPECS)
    rows = []
    for s in range(N_SEQUENCES):
        label = rng.choice(labels)
        persistent = s % 2 == 0
        if persistent:
            seen = rng.random(5) < p_detect
        else:
            seen = np.zeros(5, dtype=bool)
            seen[rng.integers(0, 5)] = True          # exactly one ghost frame
        for f in range(5):
            rows.append({"sequence_id": s + 1, "frame": f + 1, "label": label,
                         "detected": int(seen[f]), "is_persistent_obstacle": int(persistent)})
    return pd.DataFrame(rows)


if __name__ == "__main__":
    os.makedirs("data", exist_ok=True)
    rng = np.random.default_rng(SEED)
    make_scenes(rng).to_csv("data/navigation_scenes.csv", index=False)
    make_sequences(rng).to_csv("data/frame_sequences.csv", index=False)
    print("Saved data/navigation_scenes.csv and data/frame_sequences.csv")
