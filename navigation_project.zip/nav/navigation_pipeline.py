"""
navigation_pipeline.py
Core 5-stage pipeline for the Navigation System for Visually Impaired.
Data structures used: deque (circular buffer), dict (hash map),
adjacency-list graph, heapq (binary min-heap) for A*.
"""
import heapq
import math
from collections import deque, Counter
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

# Hash map: canonical real-world width (m) and hazard penalty multiplier
HAZARD_SPECS: Dict[str, Tuple[float, float]] = {
    "Staircase": (1.20, 10.0),
    "Car": (1.80, 12.0),
    "Bicycle": (0.65, 5.0),
    "Person": (0.50, 3.5),
    "Chair": (0.55, 4.0),
    "Wet_Floor": (0.45, 6.0),
}
DEFAULT_FOCAL_LENGTH_PX = 600.0
FRAME_WIDTH_PX = 640


@dataclass
class Detection:
    label: str
    confidence: float
    bbox: Tuple[int, int, int, int]  # (xmin, ymin, xmax, ymax)


@dataclass
class NavigationGuidance:
    obstacle: str
    distance_m: float
    zone: str
    risk_level: str
    direction_cue: str
    voice_prompt: str


# Stage 1: circular buffer to suppress single-frame false positives
class TemporalFrameBuffer:
    def __init__(self, window_size: int = 5, min_votes: int = 2):
        self.buffer: deque = deque(maxlen=window_size)
        self.min_votes = min_votes

    def push_and_filter(self, detections: List[Detection]) -> List[Detection]:
        labels = [d.label for d in detections if d.confidence >= 0.50]
        self.buffer.append(labels)
        counts = Counter(l for frame in self.buffer for l in frame)
        confirmed = {l for l, c in counts.items() if c >= self.min_votes}
        return [d for d in detections
                if d.label in confirmed and d.confidence >= 0.50]


# Stage 3: pinhole distance estimation and angular zone mapping
def estimate_distance(det: Detection,
                      focal_px: float = DEFAULT_FOCAL_LENGTH_PX) -> float:
    w_real, _ = HAZARD_SPECS[det.label]            # O(1) hash lookup
    p_width = max(1, det.bbox[2] - det.bbox[0])
    return (w_real * focal_px) / p_width


def classify_zone(det: Detection, frame_w: int = FRAME_WIDTH_PX) -> str:
    xc = (det.bbox[0] + det.bbox[2]) / 2
    if xc < 0.35 * frame_w:
        return "Left"
    if xc > 0.65 * frame_w:
        return "Right"
    return "Center"


# Stage 4: weighted spatial graph (adjacency list) with A* on a min-heap
class SpatialNavigationGraph:
    def __init__(self):
        self.coords: Dict[str, Tuple[float, float]] = {}
        self.adj: Dict[str, Dict[str, float]] = {}
        self.base: Dict[Tuple[str, str], float] = {}

    def add_node(self, name: str, x: float, y: float) -> None:
        self.coords[name] = (x, y)
        self.adj.setdefault(name, {})

    def add_edge(self, u: str, v: str, w: float) -> None:
        self.adj[u][v] = w
        self.adj[v][u] = w
        self.base[(u, v)] = self.base[(v, u)] = w

    def set_edge_cost(self, u: str, v: str, w: float) -> None:
        self.adj[u][v] = w
        self.adj[v][u] = w

    def _h(self, n: str, goal: str) -> float:
        (x1, y1), (x2, y2) = self.coords[n], self.coords[goal]
        return math.hypot(x1 - x2, y1 - y2)

    def a_star(self, start: str, goal: str) -> Tuple[List[str], float]:
        open_heap = [(self._h(start, goal), 0, start)]   # (f, tie, node)
        g = {start: 0.0}
        parent: Dict[str, Optional[str]] = {start: None}
        closed = set()
        tie = 0
        while open_heap:
            _, _, u = heapq.heappop(open_heap)           # O(log V)
            if u in closed:
                continue
            if u == goal:
                path = []
                while u is not None:
                    path.append(u)
                    u = parent[u]
                return path[::-1], g[goal]
            closed.add(u)
            for v, w in self.adj[u].items():
                if w == math.inf or v in closed:
                    continue
                ng = g[u] + w
                if ng < g.get(v, math.inf):
                    g[v] = ng
                    parent[v] = u
                    tie += 1
                    heapq.heappush(open_heap, (ng + self._h(v, goal), tie, v))
        return [], math.inf


def build_walkway_graph() -> SpatialNavigationGraph:
    """Sample corridor: direct path + left/right 30-degree detours."""
    g = SpatialNavigationGraph()
    g.add_node("Corridor_Start", 0.0, 0.0)
    g.add_node("Left_Detour_30deg", -2.3, 4.0)
    g.add_node("Right_Detour_30deg", 2.3, 4.0)
    g.add_node("Exit_Lobby", 0.0, 8.0)
    g.add_edge("Corridor_Start", "Exit_Lobby", 8.0)
    g.add_edge("Corridor_Start", "Left_Detour_30deg", 4.6)
    g.add_edge("Left_Detour_30deg", "Exit_Lobby", 4.6)
    g.add_edge("Corridor_Start", "Right_Detour_30deg", 5.0)
    g.add_edge("Right_Detour_30deg", "Exit_Lobby", 5.0)
    return g


# Stages 3-5: risk scoring, rerouting and voice guidance
def evaluate_navigation_step(detections, buffer, graph, start, goal, direct_edge):
    u, v = direct_edge
    graph.set_edge_cost(u, v, graph.base[(u, v)])        # reset to w0
    confirmed = buffer.push_and_filter(detections)

    worst, worst_score = None, -1.0
    for det in confirmed:
        d, zone = estimate_distance(det), classify_zone(det)
        lam = HAZARD_SPECS[det.label][1]
        if zone == "Center" and d <= 3.0:
            w0 = graph.base[(u, v)]
            graph.set_edge_cost(u, v, math.inf if d < 1.0 else w0 * lam)
        score = lam / d                                   # higher = riskier
        if score > worst_score:
            worst, worst_score = (det, d, zone), score

    route, cost = graph.a_star(start, goal)
    if worst is None:
        return None, route, cost

    det, d, zone = worst
    risk = "HIGH RISK" if (zone == "Center" and d < 1.5) else "MODERATE RISK"
    cue = "Continue Straight"
    if len(route) > 1:
        (x0, y0), (x1, y1) = graph.coords[route[0]], graph.coords[route[1]]
        bearing = round(math.degrees(math.atan2(x1 - x0, y1 - y0)))
        if bearing < 0:
            cue = f"Turn Left {abs(bearing)}\u00b0"
        elif bearing > 0:
            cue = f"Turn Right {bearing}\u00b0"
    spoken = cue.replace("\u00b0", " degrees").replace("Left", "left").replace("Right", "right")
    if cue == "Continue Straight":
        voice = f"{det.label} {d:.1f} meters on your {zone.lower()}. Continue straight."
    else:
        voice = (f"Caution: {det.label} {d:.1f} meters ahead in "
                 f"{zone.lower()}. {spoken}.")
    return NavigationGuidance(det.label, round(d, 1), zone, risk, cue, voice), route, cost
